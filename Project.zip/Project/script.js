
document.addEventListener('DOMContentLoaded', () => {
    const pdfUpload = document.getElementById('pdf-upload');
    const uploadButton = document.getElementById('upload-button');
    const abstractResult = document.getElementById('abstract-result');
    const sidebar = document.getElementById('sidebar');
    const toggleSidebar = document.querySelector('.sidebar-toggle');
    const recentSearchesList = document.getElementById('recent-searches-list');

    toggleSidebar.addEventListener('click', () => {
        sidebar.classList.toggle('open');
        if (sidebar.classList.contains('open')) {
            toggleSidebar.style.right = '320px';
        } else {
            toggleSidebar.style.right = '0';
        }
    });

    uploadButton.addEventListener('click', () => {
        const file = pdfUpload.files[0];
        if (file && file.type === 'application/pdf') {
            extractAbstractFromPDF(file);
        } else {
            alert('Please upload a valid PDF file.');
        }
    });

    async function extractAbstractFromPDF(file) {
        const reader = new FileReader();
        reader.onload = async () => {
            const pdfData = new Uint8Array(reader.result);
            const pdfjsLib = await import('https://cdnjs.cloudflare.com/ajax/libs/pdf.js/2.8.335/pdf.min.js');
            const pdf = await pdfjsLib.getDocument({ data: pdfData }).promise;
            let text = '';

            for (let i = 1; i <= pdf.numPages; i++) {
                const page = await pdf.getPage(i);
                const content = await page.getTextContent();
                content.items.forEach(item => text += item.str + ' ');
            }

            const abstract = extractAbstract(text);
            abstractResult.textContent = abstract;
            addRecentSearch(file.name);
        };

        reader.readAsArrayBuffer(file);
    }

    function extractAbstract(text) {
        const abstractStart = text.toLowerCase().indexOf('abstract');
        const abstractEnd = text.toLowerCase().indexOf('introduction');
        if (abstractStart !== -1 && abstractEnd !== -1) {
            return text.substring(abstractStart, abstractEnd).trim();
        } else {
            return 'Abstract not found in the document.';
        }
    }

    function addRecentSearch(fileName) {
        const listItem = document.createElement('li');
        listItem.textContent = fileName;
        recentSearchesList.appendChild(listItem);
    }
});
