document.addEventListener('DOMContentLoaded', function() {
    const hamburgerBtn = document.querySelector('.hamburger-btn');
    const navbar = document.querySelector('.navbar');
    const loginBtn = document.querySelector('.login-btn');
    const blurBgOverlay = document.querySelector('.blur-bg-overlay');
    const formPopup = document.querySelector('.form-popup');
    const closeBtn = formPopup.querySelector('.close-btn');
    const signupLink = document.getElementById('signup-link');
    const loginLink = document.getElementById('login-link');
    const loginForm = formPopup.querySelector('.form-box.login');
    const signupForm = formPopup.querySelector('.form-box.signup');

    hamburgerBtn.addEventListener('click', () => {
        navbar.classList.toggle('active');
    });

    loginBtn.addEventListener('click', () => {
        showPopup('login');
    });

    closeBtn.addEventListener('click', () => {
        hidePopup();
    });

    blurBgOverlay.addEventListener('click', () => {
        hidePopup();
    });

    signupLink.addEventListener('click', () => {
        showPopup('signup');
    });

    loginLink.addEventListener('click', () => {
        showPopup('login');
    });

    function showPopup(type) {
        blurBgOverlay.style.opacity = '1';
        blurBgOverlay.style.pointerEvents = 'auto';
        formPopup.style.opacity = '1';
        formPopup.style.pointerEvents = 'auto';
        if (type === 'signup') {
            loginForm.style.display = 'none';
            signupForm.style.display = 'block';
        } else {
            signupForm.style.display = 'none';
            loginForm.style.display = 'block';
        }
    }

    function hidePopup() {
        blurBgOverlay.style.opacity = '0';
        blurBgOverlay.style.pointerEvents = 'none';
        formPopup.style.opacity = '0';
        formPopup.style.pointerEvents = 'none';
    }
});
